# NL2Regex: English to regular expression with encoder-decoder networks (from scratch)

NLP course project. A sequence-to-sequence model, written in PyTorch without any pretrained model,
reads an English description such as

    lines containing the string 'dog' at least 2 times

and generates a regular expression:

    .*(dog){2,}.*

Everything is implemented in this repository: preprocessing, vocabularies, encoder, decoder, additive
attention, training loop with teacher forcing, greedy and beam-search decoding, metrics, and a regex
checker that measures whether a generated regex *behaves* like the reference.

## Data

NL-RX-Turk (Locascio et al., 2016, <https://github.com/nicholaslocascio/deep-regex>, MIT license):
10,000 pairs (description written by a crowd worker, regular expression). Quoted words in the
descriptions are placeholders (`'dog'`, `'truck'`, `'ring'`, `'lake'`) shared with the regex side.

## Layout

    src/data.py          preprocessing, vocabularies (<PAD> <UNK> <SOS> <EOS>), split, batching
    src/models.py        Encoder, additive Attention, Decoder, Seq2Seq (greedy + beam search)
    src/train.py         training loop (teacher forcing ratio, early stopping on validation EM)
    src/evaluate.py      EM, BLEU-4, perplexity, token accuracy, functional correctness
    src/regex_engine.py  parser + matcher for the NL-RX dialect (supports & and ~)
    src/analyze.py       tables, learning curves, attention heatmaps, error analysis
    src/demo.py          interactive demo: English in, regex out, test on your own lines
    results/<run>/       config, history, best checkpoint, test metrics and predictions
    results/*.md|png     comparison table, curves, attention figure, error analysis, examples

## Reproduce

    pip install torch matplotlib
    git clone --depth 1 https://github.com/nicholaslocascio/deep-regex data_raw/deep-regex
    python src/train.py --name lstm_base_s1 --seed 1                  # baseline
    python src/train.py --name lstm_attn_s1 --seed 1 --attention      # + attention
    python src/evaluate.py results/lstm_attn_s1 --beam 5
    python src/analyze.py
    python src/demo.py --run results/lstm_attn_s1

Training uses CPU only (about 13 min for the baseline and 26 min with attention).

## Functional correctness

NL-RX regexes use intersection (`A&B`) and complement (`~A`), which Python's `re` does not support,
so `src/regex_engine.py` parses them and matches whole lines. Two regexes are called functionally
equal when they accept exactly the same 600+ probe strings. This is a sampling-based test, not a
proof of equivalence. Some reference regexes accept nothing at all (for example the intersection of
`dog` and `truck`); results are therefore also reported on the "non-degenerate" subset.

## Website (browser demo)

`site/` is a static website (no server code) that runs both trained models in the browser, with the
report and the slides embedded. See `site/README.md`. Regenerate its data with
`python tools/export_site_data.py`, check JavaScript against PyTorch with `node tools/parity_test.mjs`
and `node tools/regex_parity.mjs`, and rebuild the slide viewer with `python tools/build_slides.py`.
