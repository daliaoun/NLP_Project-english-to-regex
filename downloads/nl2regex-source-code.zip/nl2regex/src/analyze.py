"""
Aggregate results of all runs into tables and figures for the report.

    python src/analyze.py            # reads results/*/ (needs evaluate.py to have been run on each run)
Outputs (in results/):  comparison.md, learning_curves.png, attention_examples.png,
                        error_analysis.md, qualitative_examples.md
"""
import json
import re
import sys
from collections import defaultdict
from pathlib import Path
from statistics import mean, pstdev

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "results"


def load_runs():
    runs = {}
    for d in sorted(RES.iterdir()):
        if not (d / "config.json").exists() or not (d / "history.json").exists():
            continue
        runs[d.name] = {
            "dir": d,
            "cfg": json.loads((d / "config.json").read_text()),
            "hist": json.loads((d / "history.json").read_text()),
            "summary": json.loads((d / "summary.json").read_text()) if (d / "summary.json").exists() else {},
            "test": json.loads((d / "test_greedy_metrics.json").read_text())
            if (d / "test_greedy_metrics.json").exists() else None,
            "beam": next(iter([json.loads(p.read_text()) for p in d.glob("test_beam*_metrics.json")]), None),
        }
    return runs


def group_name(name):
    return re.sub(r"_s\d+$", "", name)


def fmt(vals, pct=False, digits=1):
    vals = [v * 100 if pct else v for v in vals]
    if len(vals) == 1:
        return f"{vals[0]:.{digits}f}"
    return f"{mean(vals):.{digits}f} ± {pstdev(vals):.{digits}f}"


def comparison_table(runs):
    groups = defaultdict(list)
    for n, r in runs.items():
        if r["test"]:
            groups[group_name(n)].append(r)
    lines = ["| Model | Params | Seeds | Test loss | Perplexity | Token acc (%) | BLEU-4 | Exact match (%) | Functional acc (%) | Functional, non-degenerate refs (%) | Valid regex (%) |",
             "|---|---|---|---|---|---|---|---|---|---|---|"]
    for g, rs in groups.items():
        t = [r["test"] for r in rs]
        lines.append(f"| {g} | {rs[0]['cfg']['n_params']:,} | {len(rs)} | {fmt([x['loss'] for x in t], digits=3)} | "
                     f"{fmt([x['perplexity'] for x in t], digits=3)} | {fmt([x['token_acc'] for x in t], True)} | "
                     f"{fmt([x['bleu'] for x in t])} | {fmt([x['exact_match'] for x in t], True)} | "
                     f"{fmt([x['functional_acc'] for x in t], True)} | {fmt([x['functional_acc_nondegenerate'] for x in t], True)} | "
                     f"{fmt([x['valid_rate'] for x in t], True)} |")
    lines += ["", "Non-degenerate = the reference regex accepts some but not all of the probe strings "
              "(otherwise 'both accept nothing' counts as equivalent).", "", "Breakdown on the test set (exact match / functional accuracy, %):", "",
              "| Model | EM, regex unseen in training | Functional, unseen | EM, regex seen in training | Best epoch | Epochs run |",
              "|---|---|---|---|---|---|"]
    for g, rs in groups.items():
        t = [r["test"] for r in rs]
        seen = [x["em_seen_target"] for x in t if "em_seen_target" in x]
        lines.append(f"| {g} | {fmt([x['em_unseen_target'] for x in t], True)} | "
                     f"{fmt([x['func_unseen_target'] for x in t], True)} | {fmt(seen, True) if seen else '-'} | "
                     f"{fmt([r['summary'].get('best_epoch', 0) for r in rs], digits=0)} | "
                     f"{fmt([r['summary'].get('epochs_run', 0) for r in rs], digits=0)} |")
    beams = [(n, r) for n, r in runs.items() if r["beam"]]
    if beams:
        lines += ["", "Decoding strategy (same trained model, test set):", "",
                  "| Run | Decoding | BLEU-4 | Exact match (%) | Functional acc (%) | Valid regex (%) |", "|---|---|---|---|---|---|"]
        for n, r in beams:
            for lab, m in (("greedy", r["test"]), (r["beam"]["mode"], r["beam"])):
                lines.append(f"| {n} | {lab} | {m['bleu']:.1f} | {m['exact_match']*100:.1f} | "
                             f"{m['functional_acc']*100:.1f} | {m['valid_rate']*100:.1f} |")
    return "\n".join(lines)


def learning_curves(runs):
    names = list(runs)
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.4))
    cmap = plt.get_cmap("tab10")
    for i, n in enumerate(names):
        h = runs[n]["hist"]
        ep = [x["epoch"] for x in h]
        c = cmap(i % 10)
        ax[0].plot(ep, [x["train_loss"] for x in h], "--", color=c, alpha=0.8)
        ax[0].plot(ep, [x["val_loss"] for x in h], "-", color=c, label=n)
        ax[1].plot(ep, [x["val_em"] * 100 for x in h], color=c, label=n)
        ax[2].plot(ep, [x["val_bleu"] for x in h], color=c, label=n)
    ax[0].set_title("Loss (dashed = train, solid = validation)")
    ax[1].set_title("Validation exact match (%)")
    ax[2].set_title("Validation BLEU-4")
    for a in ax:
        a.set_xlabel("epoch")
        a.grid(alpha=0.3)
    ax[0].set_ylabel("token cross-entropy")
    ax[0].legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(RES / "learning_curves.png", dpi=140)
    plt.close()


def feature_flags(ref, src):
    return {
        "contains intersection (&)": "&" in ref,
        "contains negation (~)": "~" in ref,
        "contains repetition {n,m}": "{" in ref,
        "contains word boundary (\\b)": "\\b" in ref,
        "contains alternation (|)": "|" in ref,
        "long regex (>= 30 tokens)": len(re.findall(r"\\b|dog|truck|ring|lake|.", ref)) >= 30,
        "long description (>= 15 words)": len(src.split()) >= 15,
    }


def error_analysis(runs):
    out = ["# Error analysis\n"]
    for n, r in runs.items():
        p = r["dir"] / "test_greedy_predictions.jsonl"
        if not p.exists():
            continue
        rows = [json.loads(l) for l in p.read_text().splitlines()]
        out.append(f"## {n}\n")
        out.append("Accuracy by property of the reference regex / description (test set):\n")
        out.append("| Property | n | Exact match (%) | Functional (%) |\n|---|---|---|---|")
        agg = defaultdict(lambda: [0, 0, 0])
        for x in rows:
            for k, v in feature_flags(x["ref"], x["src"]).items():
                if v:
                    a = agg[k]
                    a[0] += 1
                    a[1] += x["em"]
                    a[2] += bool(x["functional"])
        for k, (c, e, f) in agg.items():
            out.append(f"| {k} | {c} | {100*e/c:.1f} | {100*f/c:.1f} |")
        invalid = [x for x in rows if x["valid"] is False]
        wrong_valid = [x for x in rows if x["valid"] and not x["functional"]]
        eq_diff = [x for x in rows if x["functional"] and not x["em"]]
        out.append(f"\nOf {len(rows)} test examples: {sum(x['em'] for x in rows)} exact matches, "
                   f"{len(eq_diff)} behaviourally equivalent but written differently, "
                   f"{len(wrong_valid)} valid but wrong, {len(invalid)} invalid regexes.\n")
        # error types for wrong, valid regexes: token edit distance bucket
        import difflib
        near = 0
        for x in wrong_valid:
            ratio = difflib.SequenceMatcher(None, x["pred"], x["ref"]).ratio()
            near += ratio >= 0.85
        out.append(f"Among the {len(wrong_valid)} valid-but-wrong outputs, {near} are 'near misses' "
                   f"(character similarity >= 0.85 with the reference).\n")
    (RES / "error_analysis.md").write_text("\n".join(out))


def qualitative(runs, name, k_ok=6, k_bad=8):
    r = runs[name]
    rows = [json.loads(l) for l in (r["dir"] / "test_greedy_predictions.jsonl").read_text().splitlines()]
    ok = [x for x in rows if x["em"]][:k_ok]
    bad = [x for x in rows if not x["functional"]][:k_bad]
    equiv = [x for x in rows if x["functional"] and not x["em"] and not x["ref_degenerate"]][:3]
    out = [f"# Qualitative examples ({name}, greedy, test set)\n"]
    for title, items in (("Correct (exact match)", ok), ("Different string, same behaviour", equiv),
                         ("Failures", bad)):
        out.append(f"## {title}\n")
        for x in items:
            out.append(f"- **Input:** {x['src']}\n  - reference: `{x['ref']}`\n  - generated: `{x['pred']}`"
                       f"{'' if x['valid'] else '  (INVALID regex)'}")
        out.append("")
    (RES / "qualitative_examples.md").write_text("\n".join(out))


def attention_figure(runs, name, n_examples=4):
    from data import build_data
    from evaluate import load_model, predict
    r = runs[name]
    model, ck = load_model(r["dir"])
    data = build_data(seed=ck["data_seed"], augment_synth=ck.get("augment_synth", False))
    rows = [x for x in data["splits"]["test"] if 6 <= len(x["src_tok"]) <= 12][:200]
    preds = predict(model, rows, data["tgt_vocab"], "greedy", keep_attention=True)
    good = [(row, p) for row, p in zip(rows, preds) if p["text"] == row["tgt_raw"] and len(p["tokens"]) <= 24][:n_examples]
    if not good:
        return
    fig, axes = plt.subplots(2, 2, figsize=(14, 9))
    for ax, (row, p) in zip(axes.ravel(), good):
        att = p["attention"].numpy()[:len(p["tokens"])]
        ax.imshow(att, aspect="auto", cmap="viridis")
        ax.set_xticks(range(len(row["src_tok"])))
        ax.set_xticklabels(row["src_tok"], rotation=60, ha="right", fontsize=8)
        ax.set_yticks(range(len(p["tokens"])))
        ax.set_yticklabels(p["tokens"], fontsize=8)
        ax.set_title(row["src_raw"][:70], fontsize=9)
    plt.suptitle("Attention weights: rows = generated regex tokens, columns = input words", fontsize=11)
    plt.tight_layout()
    plt.savefig(RES / "attention_examples.png", dpi=140)
    plt.close()


def main():
    runs = load_runs()
    if not runs:
        print("no runs found")
        return
    (RES / "comparison.md").write_text(comparison_table(runs))
    learning_curves(runs)
    error_analysis(runs)
    attn = [n for n, r in runs.items() if r["cfg"]["attention"] and r["test"]]
    if attn:
        best = max(attn, key=lambda n: runs[n]["test"]["functional_acc"])
        qualitative(runs, best)
        attention_figure(runs, best)
    print((RES / "comparison.md").read_text())


if __name__ == "__main__":
    main()
